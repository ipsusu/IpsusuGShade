INSTALLATION INSTRUCTIONS
- Copy this folder into "\gshade-presets\Custom" or "\gshade-presets\Ipsusu" (or any other preset folder)
- Copy "lut_IpsusuGameplay.png" from this folder into your "\gshade-shaders\Textures" folder.
  - (Replace the one that already exists there)
- Enable this preset ingame by navigating to where you copied this current folder!